
import './App.css'
import Pokedex from './Components/Pokedex'

function App() {

  return (
    <>
    <Pokedex />
    </>
  )
}

export default App
