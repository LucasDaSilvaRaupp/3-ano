export default function Cabecalho(){
    return(

        <header className="Cabecalho">
            
            <div className="item">  
                <h1>OI</h1>
            </div>
            
        </header>
    )
}