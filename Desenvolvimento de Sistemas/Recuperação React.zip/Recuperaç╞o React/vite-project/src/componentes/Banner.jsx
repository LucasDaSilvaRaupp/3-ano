export default function Banner(){
    return (
        <section className="Banner">
    
        <img src ="biblioteca.jpg" width="1344px" height="300px" alt="" />
        </section>
        
    )
    }