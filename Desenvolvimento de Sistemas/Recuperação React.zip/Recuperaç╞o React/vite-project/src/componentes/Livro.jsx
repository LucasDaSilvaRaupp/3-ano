export default function Livro({titulo, descricao, autor, editora}){
     return(
           
            <div className="flex">
            <img src="Príncipe.png" width="400px" height= "400px" alt=""/>
            <div/>
               
               

            <div className="Livro">
                <h1>{titulo}</h1>
                <p>{descricao}</p>
                <p>{autor}</p>
                <p>{editora}</p>
            </div>
    </div>
     )
}