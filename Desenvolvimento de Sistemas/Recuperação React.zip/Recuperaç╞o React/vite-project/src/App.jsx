import Cabecalho from './componentes/Cabecalho'
import Banner from './componentes/Banner'
import Galeria from './componentes/Galeria'
import Livro from './componentes/Livro'
import Rodape from './componentes/Rodape'
import './App.css'

function App() {

  return (
    <>
      <Cabecalho />
      <Banner />
      <Livro 
      titulo=" ㅤTítulo - O Pequeno Príncipe"
      descricao="ㅤDescirção - Este é um livre sobre o Pequeno Príncipe"
      autor="ㅤAutor - Antoine de Saint-Exupéry"
      editora="ㅤEditora - Companhia das Letras"
      />
      <center><h1>Livros Disponíveis</h1></center>
      <Galeria />
      <Rodape />
    </>
  )
}

export default App