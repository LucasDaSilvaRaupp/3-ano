const express = require('express'); 
const bodyParser = require('body-parser');

const app = express();
    app.use(bodyParser.json());

let livros = [];
    app.get('/livros', (req, res) => { 
    res.json(livros); 
    });
    
app.get('/livros/:placa', (req, res) => { 
    const { placa } = req.params; 
    const livros = livros.find(v => v.placa === placa); 
        if (livros) { 
            res.json(livros); 
        } 
        else { 
            res.status(404).json({ message: 'Veículo não encontrado.' }); 
        } 
        });
        
app.post('/livros', (req, res) => { 
    const { autor, titulo, editora } = req.body; 
    const livros= { autor, titulo, editora, ano }; 
        livros.push(livros); 
        res.status(201).json({ message: 'Veículo cadastrado com sucesso.' }); 
        });

app.put('/livros/:titulo', (req, res) => { 
    const { autor } = req.params; 
    const { titulo, editora } = req.body; 
    const livros= livros.find(v => v.autor === autor); 
        if (livros) { 
            livros.autor = autor || livros.autor; 
            livros.titulo = titulo || livros.titulo; 
            livros.editora = editora || livros.editora; 
            res.json({ message: 'Informações do livro atualizadas com sucesso.' });
        } 
        else {
            res.status(404).json({ message: 'Livro não encontrado' }); 
        } 
        });
            
app.delete('/livros/:autor', (req, res) => { 
    const { autor } = req.params; 
    const livrosIndex = livros.findIndex(v => v.autor === autor); 
        if (livrosIndex !== -1) { 
            livros.splice(livrosIndex, 1); 
            res.json({ message: 'Livro excluído com sucesso.' }); 
        } 
        else { 
            res.status(404).json({ message: 'Livro não encontrado.' }); 
        } 
        });

const port = 3000; 
    app.listen(port, () => { 
    console.log(`Servidor rodando em http://localhost:${port}`); 
});