import './App.css'
import Tericeira from './Componentes/Pagina3'

function App() {

  return (
    <>
      <div>
      <Tericeira />  
      </div>
    </>
  )
}

export default App
