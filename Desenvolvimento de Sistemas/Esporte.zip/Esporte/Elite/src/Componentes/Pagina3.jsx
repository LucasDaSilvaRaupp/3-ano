export default function Terceira() {

    return(
    <div>

    <div className="Judo">
    <img src="Judo.png" alt="" />
    </div>

    </div>
    )

  }