
export default function Primeira(){
  
    const redirecionarParaSegunda = () => {
       
        history.push('Segunda');
    };

    return(<div className="Primeira">

    <div className="Esporte">
    <img src="Logo.png" alt="" />
    </div>

    <h4 className="Titulo">Seu aplicatido de praticas esportivas</h4>
    
    <div className="Botão1">
    <input type="text" className="Nome" placeholder="Insira seu nome" />
    </div>
   
    <div className="Botão2">
    <input type="text" className="Nome" placeholder="Insira sua senha" />
    </div>  
    
    <h5 className="Esqueceu">Esqueceu a senha?</h5> 


    <button className="Botão3" onClick={redirecionarParaSegunda}>Entrar</button>
 
    
    <h5 className="Cadastro">Não tem uma conta ainda? Cadastre-se</h5>
    </div>  
    )  
}