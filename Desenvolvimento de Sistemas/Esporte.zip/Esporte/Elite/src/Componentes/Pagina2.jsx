
export default function Segunda(){

    return(

        <div className="Segunda">

        <h3 className="Rua">R. Sílvio Coelho De Alverga,165</h3>
        
        <h2 className="Sugestoes">Sugestões</h2>

        <div className="Judo">
        <img src="Judo.png" alt="" />
        </div>

        <h3>🔵⚫⚫⚫</h3>

        <h2 className="Favoritos">Favoritos</h2>

        <div className="Futebol">
        <img src="Futebol.png" alt="" />
        </div>

        <div className="Natacao">
        <img src="Nataçao.png" alt="" />
        </div>

        <div className="Elementos">
        
        <figure className="image-container">
        <button> <img src="casa.png" height="30px" width="30px" alt="" /> </button>
        <figcaption>Início</figcaption>
        </figure>

        <figure className="image-container">
        <button> <img src="lupa.png" height="30px" width="30px" alt="" /> </button>
        <figcaption>Buscar</figcaption>
        </figure>

        <figure className="image-container">
        <button> <img src="prancheta.png" height="30px" width="30px" alt="" /> </button>
        <figcaption>Eventos</figcaption>
        </figure>

        <figure className="image-container">
       <button> <img src="Perfil.png" height="30px" width="30px" alt="" /> </button>
        <figcaption>Perfil</figcaption>
        </figure>
        </div>

        </div>  
    )
}