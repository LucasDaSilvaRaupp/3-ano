function Banner(){
    return (
        <section className="Banner">
    
        <img src="./grupo.jpg"></img>  
        
        </section>
        
    )
    }
    export default Banner;