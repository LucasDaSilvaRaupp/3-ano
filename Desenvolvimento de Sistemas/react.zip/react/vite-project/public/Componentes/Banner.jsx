function Banner(){
    return (
        <section className="Banner">
    
        <img src ="grupo.jpg" alt='grupo'/>
        </section>
        
    )
    }
    export default Banner;