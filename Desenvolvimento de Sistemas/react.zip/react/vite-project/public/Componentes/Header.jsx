function Logo() {

    return (
        <header>
        <h1>🥰 Senai 🥰</h1>
        </header>

)

}
export default Logo;