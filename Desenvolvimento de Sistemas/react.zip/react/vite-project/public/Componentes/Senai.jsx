function Senai(){
    return(
        <section>
      <h2>Senai</h2>
      <p>Essa é uma página do Senai</p>
    </section>
    )
}
export default Senai;