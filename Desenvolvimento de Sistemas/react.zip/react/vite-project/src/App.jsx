function App() {

  return (
   <div>
    <img src ="Senai.png" width={100} height={50} alt="senai"/>   
    <header>
      <h2>
        Evento Senai
      </h2>
      <h3>
      10:00 às 22:00 - Senai São José
      </h3>
      <img src ="ffffff.png" width={300} height={200} alt="colegio"/><img src ="ffffff.png" width={300} height={200} alt="colegio"/><img src ="ffffff.png" width={300} height={200} alt="colegio"/> <img src ="pessoa.jpg" width={300} height={200} alt="pesoa"/>   <img src ="ffffff.png" width={300} height={200} alt="colegio"/> 
    </header>
    <table>
      <thead>
        <tr>
          <th> </th>
        </tr>
      </thead>
    </table>
    
    <img src ="ffffff.png" width={300} height={200} alt="colegio"/> <img src ="meajuda.jpg" width={200} height={200}  alt="Escola S"/> <img src ="meajuda.jpg" width={200} height={200}  alt="Escola S"/> <img src ="meajuda.jpg" width={200} height={200}  alt="Escola S"/> <img src ="ffffff.png" width={300} height={200} alt="colegio"/> 
    <img src ="ffffff.png" width={300} height={200} alt="colegio"/> <img src ="meajuda.jpg" width={200} height={200}  alt="Escola S"/> <img src ="meajuda.jpg" width={200} height={200}  alt="Escola S"/> <img src ="meajuda.jpg" width={200} height={200}  alt="Escola S"/> <img src ="ffffff.png" width={300} height={200} alt="colegio"/> 
    

   </div>

  )
}

export default App